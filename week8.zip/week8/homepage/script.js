function showMessage() {
  alert("Hello, Tahmid here! Thanks for visiting my site 😊");
}

function submitForm(event) {
  event.preventDefault();
  alert("Thank you! Your message has been received.");
}

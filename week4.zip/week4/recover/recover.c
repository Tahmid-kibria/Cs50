#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef uint8_t BYTE; // 1 byte

int main(int argc, char *argv[])
{
    // Check for proper usage
    if (argc != 2)
    {
        printf("Usage: ./recover FILE\n");
        return 1;
    }

    // Open memory card
    FILE *card = fopen(argv[1], "r");
    if (card == NULL)
    {
        printf("Could not open %s.\n", argv[1]);
        return 1;
    }

    BYTE buffer[512];   // Buffer to hold each block
    FILE *img = NULL;   // Pointer for output JPEG
    int file_count = 0; // JPEG counter
    char filename[8];   // Filename buffer (###.jpg + null terminator)

    // Read blocks of 512 bytes
    while (fread(buffer, sizeof(BYTE), 512, card) == 512)
    {
        // Check if the block is the start of a JPEG
        bool is_jpeg_start = buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff &&
                             (buffer[3] & 0xf0) == 0xe0;

        if (is_jpeg_start)
        {
            // Close previous JPEG if any
            if (img != NULL)
            {
                fclose(img);
            }

            // Create new JPEG file
            sprintf(filename, "%03d.jpg", file_count++);
            img = fopen(filename, "w");
            if (img == NULL)
            {
                printf("Could not create %s.\n", filename);
                fclose(card);
                return 1;
            }
        }

        // Write block to current JPEG if a JPEG file is open
        if (img != NULL)
        {
            fwrite(buffer, sizeof(BYTE), 512, img);
        }
    }

    // Close any remaining files
    if (img != NULL)
    {
        fclose(img);
    }

    fclose(card);
    return 0;
}

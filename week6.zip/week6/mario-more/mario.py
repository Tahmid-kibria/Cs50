from cs50 import get_int


def main():
    # Prompt user for height until valid input is given
    while True:
        height = get_int("Height: ")
        if 1 <= height <= 8:
            break

    # Build the pyramid
    for i in range(1, height + 1):
        # Print left spaces
        print(" " * (height - i), end="")

        # Print left hashes
        print("#" * i, end="")

        # Print gap between pyramids
        print("  ", end="")

        # Print right hashes
        print("#" * i)


if __name__ == "__main__":
    main()

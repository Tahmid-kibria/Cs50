from cs50 import get_string


def main():
    # Get text input from the user
    text = get_string("Text: ")

    # Count letters, words, and sentences
    letters = count_letters(text)
    words = count_words(text)
    sentences = count_sentences(text)

    # Compute averages per 100 words
    L = (letters / words) * 100
    S = (sentences / words) * 100

    # Coleman-Liau index
    index = 0.0588 * L - 0.296 * S - 15.8
    grade = round(index)

    # Output grade level
    if grade < 1:
        print("Before Grade 1")
    elif grade >= 16:
        print("Grade 16+")
    else:
        print(f"Grade {grade}")


def count_letters(text):
    count = 0
    for c in text:
        if c.isalpha():
            count += 1
    return count


def count_words(text):
    # Words are separated by spaces
    return len(text.split())


def count_sentences(text):
    count = 0
    for c in text:
        if c in ['.', '!', '?']:
            count += 1
    return count


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
def get_int(prompt):
    """
    Repeatedly prompt the user until they enter something that can be
    converted to an int (mimics cs50.get_int's basic validation).
    """
    while True:
        try:
            s = input(prompt)
        except EOFError:
            # If input is closed, just continue prompting
            continue
        try:
            return int(s)
        except ValueError:
            # not an integer — reprompt
            continue


def main():
    # prompt until a valid height between 1 and 8 (inclusive) is given
    while True:
        height = get_int("Height: ")
        if 1 <= height <= 8:
            break

    # print the half-pyramid aligned to bottom-left
    for row in range(1, height + 1):
        spaces = height - row
        hashes = row
        print(" " * spaces + "#" * hashes)


style50 mario.pyif __name__ == "__main__":
    main()

# Ask the user for their name
name = input("What is your name? ")

# Print a greeting to the user
print(f"hello, {name}")

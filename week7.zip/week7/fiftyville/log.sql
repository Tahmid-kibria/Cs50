SELECT * FROM crime_scene_reports
WHERE date = 20240728 AND street = 'Humphrey Street';

SELECT * FROM interviews WHERE date = 20240728;
SELECT * FROM bakery_security_logs
WHERE date = 20240728 AND hour = 10 AND minute <= 15 AND activity = 'exit';
SELECT name, phone_number, license_plate
FROM people
WHERE license_plate IN (
    SELECT license_plate
    FROM bakery_security_logs
    WHERE date = 20240728 AND hour = 10 AND minute <= 15 AND activity = 'exit'
);
SELECT * FROM atm_transactions
WHERE atm_location = 'Leggett Street' AND date = 20240728 AND transaction_type = 'withdraw';
SELECT name
FROM people
JOIN bank_accounts ON people.id = bank_accounts.person_id
WHERE account_number IN (
    SELECT account_number
    FROM atm_transactions
    WHERE atm_location = 'Leggett Street' AND date = 20240728
);
SELECT * FROM phone_calls
WHERE date = 20240728 AND duration < 60;
SELECT * FROM flights
WHERE origin_airport_id = (
    SELECT id FROM airports WHERE city = 'Fiftyville'
)
AND date = 20240729
ORDER BY hour, minute
LIMIT 1;
SELECT name
FROM people
JOIN passengers ON people.passport_number = passengers.passport_number
WHERE flight_id = <earliest flight id>;
SELECT name
FROM people
WHERE phone_number IN (
    SELECT receiver
    FROM phone_calls
    WHERE caller = (SELECT phone_number FROM people WHERE name = '<thief>')
      AND date = 20240728
      AND duration < 60
);

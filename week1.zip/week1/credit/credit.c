#include <cs50.h>
#include <stdio.h>

int main(void)
{

    long number = get_long("Number: ");

    // Variables for calculation
    int sum = 0;
    int count = 0;
    long temp = number;

    // Luhn’s Algorithm
    while (temp > 0)
    {
        int digit = temp % 10;

        if (count % 2 == 1)
        {
            int product = digit * 2;
            if (product > 9)
            {
                sum += (product % 10) + (product / 10);
            }
            else
            {
                sum += product;
            }
        }
        else
        {
            sum += digit;
        }

        temp /= 10;
        count++;
    }

    bool valid = (sum % 10 == 0);

    long start = number;
    while (start >= 100)
    {
        start /= 10;
    }

    if (valid)
    {
        if ((start == 34 || start == 37) && count == 15)
        {
            printf("AMEX\n");
        }
        else if (start >= 51 && start <= 55 && count == 16)
        {
            printf("MASTERCARD\n");
        }
        else if ((start / 10 == 4) && (count == 13 || count == 16))
        {
            printf("VISA\n");
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }
}

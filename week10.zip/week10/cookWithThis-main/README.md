# cookWithThis

A React app to find recipes with the ingredients that you have. Uses Groq API.

Try it right now: https://surajcdry.github.io/cookWithThis/
# Project Title Here

#### Video Demo: (https://www.youtube.com/watch?v=rDIb8hwss4I&list=PLdadJjtYx3t3mm0m1jISKdSvwNVQ7AO9U&index=32)

#### Description:
This project is a [brief description of what your project does]. It aims to [explain the problem it solves or the value it provides]. The project was implemented using [list languages, frameworks, libraries used] and demonstrates skills learned throughout the CS50x course.

---

### Features:
- Feature 1: [Describe feature and functionality]
- Feature 2: [Describe feature and functionality]
- Feature 3: [Describe feature and functionality]
- [Add more features if needed]

---

### How It Works:
1. [Step 1: How the project starts or how users interact with it]
2. [Step 2: Describe user actions or system processes]
3. [Step 3: What the project outputs or final results]
4. [Add steps as necessary]

---

### Files and Structure:
- `file1.ext` — [Describe its purpose]
- `file2.ext` — [Describe its purpose]
- `folder/` — [If you have folders, describe their contents]
- [Add any other relevant files or directories]

---

### Design Decisions:
- Decision 1: [Explain why you chose a specific approach, library, or method]
- Decision 2: [Explain another key choice in your project]
- [Add more design reasoning as necessary]

---

### Challenges and Solutions:
- Challenge 1: [Describe a problem you faced and how you solved it]
- Challenge 2: [Describe another problem and solution]
- [Optional: mention any planned improvements or limitations]

---

### Future Work:
- [Feature 1 you want to add in the future]
- [Feature 2 you want to add in the future]

---



# Smart Study Planner

#### Video Demo: (https://www.youtube.com/watch?v=rDIb8hwss4I&list=PLdadJjtYx3t3mm0m1jISKdSvwNVQ7AO9U&index=32)

#### Description:
The Smart Study Planner is a web-based application designed to help students organize their study schedules efficiently. Its primary goal is to improve productivity and ensure balanced study routines by allowing users to create, track, and prioritize their tasks and study sessions. The project was implemented using **Python (Flask)** for the backend, **JavaScript** for interactive features, **HTML/CSS** for frontend design, and **SQLite** for data storage.

This project demonstrates the application of programming skills learned throughout the CS50x course, including web development, database management, and interactive UI design. Users can sign up for an account, create multiple study plans, and receive reminders for upcoming tasks. The system also provides analytics on study patterns to help students identify their most productive times.

---

### Features:
- **User Authentication**: Secure sign-up and login system with hashed passwords.
- **Task Management**: Users can add, edit, and delete study tasks with deadlines.
- **Priority Levels**: Assign tasks with different priority levels to focus on important topics first.
- **Reminders & Notifications**: Email reminders for upcoming tasks (implemented using Flask-Mail).
- **Study Analytics**: Visual graphs showing hours studied per day and productivity trends.
- **Responsive Design**: Works seamlessly on both desktop and mobile devices.
- **Search & Filter**: Easily search for tasks and filter by subject, priority, or deadline.

---

### How It Works:
1. **User Registration/Login**: Users create an account or log in securely.
2. **Create Study Plan**: Users can add tasks, set deadlines, and assign priority levels.
3. **Track Progress**: Completed tasks can be marked done, and users can see progress over time.
4. **Receive Reminders**: The system sends automated email reminders before deadlines.
5. **Analytics Dashboard**: Users can view charts showing their study habits, completed tasks, and areas needing improvement.
6. **Edit & Organize**: Users can edit tasks, reorder priorities, and delete tasks as needed.

---

### Files and Structure:
- `app.py` — Main Flask application, handles routing and backend logic.
- `templates/` — HTML templates for each page (login, dashboard, analytics, task management).
- `static/` — CSS stylesheets, JavaScript files, and images.
- `database.db` — SQLite database storing user accounts, tasks, and analytics data.
- `requirements.txt` — List of Python packages required to run the project.
- `README.md` — Project documentation.
- `utils.py` — Helper functions for tasks such as sending emails and calculating analytics.

---

### Design Decisions:
- **Flask over Django**: Chose Flask for its simplicity and flexibility for a small to medium-scale project.
- **SQLite Database**: Easy to implement within the CS50 Codespace environment; sufficient for project scope.
- **JavaScript for Interactivity**: Dynamic content updates without page reloads improved user experience.
- **Email Notifications**: Added to provide real-world utility and enhance user engagement.
- **Responsive CSS**: Ensured accessibility across devices for students who study on phones and tablets.

---

### Challenges and Solutions:
- **Challenge 1**: Implementing email reminders without spamming users.
  **Solution**: Configured Flask-Mail to send one reminder per task 24 hours before the deadline.
- **Challenge 2**: Displaying analytics charts dynamically for each user.
  **Solution**: Used Chart.js and fetched task data via Flask API endpoints.
- **Challenge 3**: Ensuring secure user authentication.
  **Solution**: Used Werkzeug’s password hashing functions to store encrypted passwords and prevent unauthorized access.
- **Challenge 4**: Managing time zones for deadlines and notifications.
  **Solution**: Standardized all times to UTC in the backend and converted to local time on the frontend.

---

### Future Work:
- Integrate **Google Calendar API** to sync study plans with real calendars.
- Add a **Pomodoro timer** feature to encourage focused study sessions.
- Implement **AI-based suggestions** for optimal study schedules based on user performance.
- Support **group study sessions** where multiple users can collaborate on shared tasks.
- Improve **accessibility features**, such as dark mode and screen reader compatibility.

---





#### Author:
- Name: Tahmid Kibria
- GitHub: Tahmid-kibria
- edX: 2511_HQX2
- Location: Gazipur,Bangladesh
- Date: 11/10/2025
